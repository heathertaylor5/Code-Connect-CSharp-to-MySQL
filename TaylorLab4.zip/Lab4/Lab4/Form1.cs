﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using System.Configuration;
using System.IO;
using Org.BouncyCastle.Utilities;
using System.Runtime.CompilerServices;

namespace Lab4
{
    /*Heather Taylor
    *June 5, 2023
    *This program connects to a MySQL database and runs CRUD operations with the data.
    *There are two tabs that have different responsibilities including updating a dgv,
    *Adding new items to the database, deleting items from the database, and more.
    */
    public partial class Form1 : Form
    {
        //Class-level output file
        StreamWriter TaylorLog = new StreamWriter("TaylorLog.txt");

        //declare connection string
        static string connStr = ConfigurationManager.ConnectionStrings["Employees"].ConnectionString;

        //Create connection
        MySqlConnection conn = new MySqlConnection(connStr);

        public Form1()
        {
            InitializeComponent();
        }

        //form load
        private void Form1_Load(object sender, EventArgs e)
        {
            WriteToLog("Name: Heather Taylor");
            WriteToLog("Date: " + DateTime.Now.ToString());
            try
            {
                //open the connection
                conn.Open();
            }
            catch (Exception ex) {
                HandleError("Load Error", ex.Message);
            }
            //Call functions for form load
            BuildDatabase();
            DeleteFamilies();
            ResetView();
            ResetRevise();
            FixInvalids();
        }

        //Form Closing - Close the connection & the StreamWriter Object
        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            conn.Close();
            TaylorLog.Close();
        }

        //lst Tables selection change
        private void lstTables_SelectedIndexChanged(object sender, EventArgs e)
        {
            //set combobox selection to nothing
            cboSearch.SelectedIndex = -1;

            if (lstTables.SelectedIndex != -1)
            {
                //get the selected value from the listbox
                string table = lstTables.Text;

                //create the query & command for the selected table
                string tableQuery = $"select * from {table}";
                UpdateDGV(tableQuery);

            }
        }

        //ComboBox value changed
        private void cboSearch_SelectedValueChanged(object sender, EventArgs e)
        {
            //set the listbox to have nothing selected
            lstTables.SelectedIndex = -1;

            if (cboSearch.SelectedIndex != -1)
            {
                if (cboSearch.Text == "Average Salaries")
                {
                    //create string for query to find average employee salary
                    string avgQuery = "select e.emp_no, concat(e.last_name, ', ', e.first_name) as 'Name', " +
                        "concat('$', format(avg(s.salary), 2)) as 'Avg Salary' from employees e " +
                        "INNER JOIN salaries s on e.emp_no = s.emp_no Group by s.emp_no order by Name";
                    UpdateDGV(avgQuery);
                }
                else
                {
                    //get the values from the dateTime pickers
                    string start = dtpStartDate.Value.ToString("yyyy-MM-dd");
                    string end = dtpEndDate.Value.ToString("yyyy-MM-dd");

                    //create string for query
                    string hireQuery = $"select emp_no, concat(last_name, ', ', first_name) as 'Name', Date_Format(hire_date, '%m / %d/ %Y') as hire_date " +
                        $"from employees where hire_date between '{start}' and '{end}' order by hire_date";
                    UpdateDGV(hireQuery);
                }
            }
        }
        //dept radio button checkchanged
        private void radDept_CheckedChanged(object sender, EventArgs e)
        {
            if (radDept.Checked)
            {
                NewDeptEnabled(true);
            }
            else
            {
                NewDeptEnabled(false);
            }
        }
        //remove title radio button checkchanged
        private void radRemoveTitle_CheckedChanged(object sender, EventArgs e)
        {
            if (radRemoveTitle.Checked)
            {
                NewDeptEnabled(false);
            }
            else
            {
                NewDeptEnabled(true);
            }
        }

        //add deptartment button is clicked
        private void btnAddDept_Click(object sender, EventArgs e)
        {
            if (txtDept.Text.Length >= 5 && nudDept.Value > 0 && nudDept.Value < 100)
            {
                //get the values from the input fields 
                string newDept = txtDept.Text;
                string deptNo = "d0" + nudDept.Value.ToString();

                //ask the user if they're sure they want to update
                DialogResult res = MessageBox.Show("Are you sure you want to add the following department?\n" +
                    $"Dept No: {deptNo}\nDept Name: {newDept}", "Confirm Addition",
                    MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                //if yes, perform the query
                if (res == DialogResult.Yes)
                {
                    string insertDept = $"INSERT INTO departments (dept_no, dept_name) VALUES ('{deptNo}', '{newDept}')";
                    int added = NonQuery(insertDept, "Query Error");
                    if (added > 0)
                    {
                        MessageBox.Show($"Confirmation: {added} record(s) added", "Addition Completed");
                    }
                    else
                    {
                        HandleError("Query Error", $"Could not add {deptNo}: {newDept}");
                    }
                }
            } else if (txtDept.Text.Length < 5)
            {
                HandleError("Input Error", "Department Name must be at least 5 characters");
            } else
            {
                HandleError("Input Error", "Department Number must be a number higher than 0 and less than 100");
            }
        }
        //User selectes a new title from the listbox
        private void lstTitles_SelectedIndexChanged(object sender, EventArgs e)
        {
            //Clear the employee number listbox
            lstEmpNo.Items.Clear();
            if (lstTitles.SelectedIndex != -1)
            {
                //get the title name and run the query
                string title = lstTitles.Text;
                string sqlTitle = $"select emp_no from titles where title = '{title}'";
                DataTable employees = QueryExecution(sqlTitle);
                //run a foreach loop to populate the employee listbox
                foreach (DataRow row in employees.Rows)
                {
                    string empNo = row[0].ToString();
                    lstEmpNo.Items.Add(empNo);
                }
            }
        }
        //Delete title button is clicked
        private void btnDeleteTitle_Click(object sender, EventArgs e)
        {
            //Verify that both listboxes have an item selected
            if (lstTitles.SelectedIndex != -1 && lstEmpNo.SelectedIndex != -1)
            {
                //get the values from the listboxes
                int empNo = Convert.ToInt32(lstEmpNo.Text);
                string title = lstTitles.Text;
                //Confirm that the user wants to delete
                DialogResult confirm = MessageBox.Show($"Are you sure you want to remove the title '{title}' from employee {empNo}?",
                    "Confirm Deletion", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (confirm == DialogResult.Yes)
                {
                    //Create and run the query
                    string sqlDelete = $"DELETE FROM titles WHERE emp_no = {empNo} AND title = '{title}'";
                    int deleted = NonQuery(sqlDelete, "Query Error");
                    if (deleted > 0)
                    {
                        //Confirm that it has been deleted and clear empNo list box. Reset titles listbox
                        MessageBox.Show($"Confirmation {deleted} record(s) deleted", "Deletion Completed");
                        lstEmpNo.Items.Clear();
                        lstTitles.SelectedIndex = -1;
                    }
                    else
                    {
                        //if nothing is deleted
                        HandleError("Query Error", "Could not delete Record");
                    }
                }
            }
        }

        /*Name: HandleError
         *Sent: string error type, string error
         *Returned: none
         *This function works by taking in the type of error and deciding what to do based on that info*/
        private void HandleError(string type, string msg)
        {
            switch (type)
            {
                case "Load Error":
                    MessageBox.Show(msg + "\nClosing Form", type);
                    this.Close();
                    break;
                case "Query Error":
                    MessageBox.Show(msg + "\nResetting Form", type);
                    ResetView();
                    ResetRevise();
                    break;
                case "Date Error":
                    MessageBox.Show($"Could not find the {msg} date\nSetting calendars to now", type);
                    dtpEndDate.Value = DateTime.Now;
                    dtpStartDate.Value = DateTime.Now;
                    break;
                default:
                    MessageBox.Show(msg, type);
                    break;
            }
        }

        /*Name: BuildDatabase
         *Sent: None
         *Returned: None
         *This function runs the script to build the database*/
        private void BuildDatabase()
        {
            //run the script
            string script = File.ReadAllText("emp.sql");
            MySqlCommand command = new MySqlCommand(script, conn);
            try
            {
                command.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                HandleError("Load Error", ex.Message);
            }
        }

        /*Name: DeleteFamilies
         *Sent: None
         *Returned: None
         *This function drops the families table from the database*/
        private void DeleteFamilies()
        {
            string delFam = "Drop table if exists families";
            MySqlCommand cmd = new MySqlCommand(delFam, conn);
            try
            {
                cmd.ExecuteNonQuery();
                WriteToLog(delFam);
            }
            catch (Exception ex)
            {
                HandleError("Load Error", ex.Message);
            }
        }

        /*Name: ResetView
         *Sent: None
         *Returned: None
         *This function resets the items in the View tab*/
        private void ResetView()
        {
            //Show all the tables in the database
            string tables = "show tables";
            DataTable allTables = QueryExecution(tables);
            foreach (DataRow row in allTables.Rows)
            {
                string tName = row[0].ToString();
                lstTables.Items.Add(tName);
            }
            //format datetime pickers
            dtpStartDate.CustomFormat = "MM / dd/ yyyy";
            dtpEndDate.CustomFormat = "MM / dd/ yyyy";

            //Find the earliest hire date to set the date/time picker
            string earliestDate = "select min(hire_date) from employees";
            DateTime earlyHire = DateTimeQuery(earliestDate);
            if(earlyHire.Date != DateTime.Now.Date)
            {
                dtpStartDate.Value = earlyHire;
            }
            else
            {
                HandleError("Date Error", "earliest");
            }

            //Find the latest hire date and set the date/time picker
            string latestDate = "select max(hire_date) from employees";
            DateTime latestHire = DateTimeQuery(latestDate);
            if (latestHire.Date != DateTime.Now.Date)
            {
                dtpEndDate.Value = latestHire;
            }
            else
            {
                HandleError("Date Error", "latest");
            }
        }

        /*Name: ResetRevise
         *Sent: None
         *Returned: None
         *This function resets the data in the revise tab by calling default queries*/
        public void ResetRevise()
        {
            //Find the distinct titles from the titles table
            string sqlTitles = "select distinct title from titles order by title";
            DataTable titleTable = QueryExecution(sqlTitles);
            //populate the listbox
            foreach (DataRow row in titleTable.Rows)
            {
                string title = row[0].ToString();
                lstTitles.Items.Add(title);
            }
            NewDeptEnabled(true);
        }

        /*Name: NewDeptEnabled
         *Sent: bool enabled
         *Returned: None
         *This function enables and disables the appropriate groupboxes*/
        private void NewDeptEnabled(bool enabled)
        {
            if (enabled)
            {
                grpTitles.Enabled = false;
                grpDept.Enabled = true;
            }
            else
            {
                grpTitles.Enabled = true;
                grpDept.Enabled = false;
            }
        }

        /*Name: FixInvalids
         *Sent: None
         *Returned: None
         *This function calls a query to update any invalid to_date dates to today*/
        private void FixInvalids()
        {
            //find today's date & format
            DateTime today = DateTime.Now;
            string formatToday = today.ToString("yyyy-MM-dd");
            //Create an array of tables that need to be updated
            string[] tables = { "dept_emp", "dept_manager", "salaries", "titles" };
            //loop through the array
            foreach (string table in tables)
            {
                //create the string with the appropriate data
                string sqlFix = $"Update {table} set to_date = '{formatToday}' where to_date > '{formatToday}'";
                NonQuery(sqlFix, "Load Error");
            }
        }

        /*Name: UpdateDGV
         *Sent: String query
         *Returned: None
         *This function updates the dgv based on the query sent in*/
        private void UpdateDGV(string query)
        {
            //create the dataTable
            DataTable dataTable = QueryExecution(query);
            //Create the binding source
            BindingSource tableInfo = new BindingSource();
            //Set the data source of the binding source to the data table that contains the results of the query
            tableInfo.DataSource = dataTable;
            //Set the datagrid data source to the binding source
            dgvResults.DataSource = tableInfo;
            //Set the binding navigator binding source to the binding source created
            bdnDataGrid.BindingSource = tableInfo;
            bdnDataGrid.Show();
        }

        /*Name: NonQuery
         *Sent: string query
         *Returned: int
         *This function is used to execute a non-query. It writes to the log and returns an int of rows updated*/
        private int NonQuery(string query, string errType)
        {
            int success = 0;
            MySqlCommand cmd = new MySqlCommand(query, conn);
            try
            {
                //Run the sql statement
                success = cmd.ExecuteNonQuery();
                WriteToLog(query);
            }
            catch (Exception ex)
            {
                HandleError(errType, ex.Message);
            }
            return success;
        }

        /*Name: WriteToLog
        *Sent: string message
        *Returned: none
        *This function writes to the output file in bin/debug*/
        private void WriteToLog(string msg)
        {
            TaylorLog.WriteLine("Command: " + msg);
        }

        /*Name: Query Execution
         *Sent: string query
         *Returned: DataTable
         *This function executes the query sent in and returns the DataTable Created*/
        private DataTable QueryExecution(string query)
        {
            MySqlCommand cmd = new MySqlCommand(query, conn);
            DataTable results = new DataTable();
            try
            {
                results.Load(cmd.ExecuteReader());
                WriteToLog(query);
            }
            catch (Exception ex)
            {
                HandleError("Query Error", ex.Message);
            }
            return results;
        }

        /*Name: DateTimeQuery
         *Sent: string query
         *Returned: DateTime object
         *This function finds the dateTime object based on the query sent in*/
        private DateTime DateTimeQuery(string query) 
        {
            //set value to return
            DateTime result = DateTime.Now;
            //create connection
            MySqlCommand date = new MySqlCommand(query, conn);
            try
            {
                //Execute the scalar
                result = (DateTime)date.ExecuteScalar();
                WriteToLog(query);
            }catch(Exception ex) 
            {
                HandleError("Load Error", ex.Message);
            }
            return result;
        }
    }
}
